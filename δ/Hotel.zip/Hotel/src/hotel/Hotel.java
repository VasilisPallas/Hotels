package hotel;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Hotel {

    public static void main(String[] args) throws ClassNotFoundException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = (Connection) DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/ksenodoxio",
                    "hoteluser", "cangetin");
            Statement s2 = (Statement) con.createStatement();
            ResultSet r = s2.executeQuery("select Onoma_Ypallilou, Epwnumo_Ypallilou\n"
                    + "from Ypallillos, Xrewseis_Pelatwn, Proion\n"
                    + "where Ypallillos.Id_Ypallilou = Xrewseis_Pelatwn.Id_Ypallilou \n"
                    + "and Xrewseis_Pelatwn.Id_Proiontos = Proion.Id_Proiontos \n"
                    + "and Aksia_Monadas_Proiontos*Posotita_Proiontos = \n"
                    + "(select max(Aksia_Monadas_Proiontos*Posotita_Proiontos) \n"
                    + "from Proion, Xrewseis_Pelatwn \n"
                    + "where Xrewseis_Pelatwn.Id_Proiontos = Proion.Id_Proiontos)\n"
                    + "group by Onoma_Ypallilou, Epwnumo_Ypallilou;");

            System.out.print("ο υπάλληλος με τη μεγαλύτερη αξία πωλήσεων είναι ο ");
            while (r.next()) {
                String onoma = r.getString("Onoma_Ypallilou");
                String epwnimo = r.getString("Epwnumo_Ypallilou");

                System.out.println(onoma + " "+ epwnimo);
            }

            con.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
